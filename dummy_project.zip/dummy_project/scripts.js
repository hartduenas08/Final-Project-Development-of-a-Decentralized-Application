const web3 = new Web3(window.ethereum);
var account;
const CONTRACT_ADDR = "0xf977227F264cDa16033769ff493647571E5C12D0";
const CONTRACT_ABI = [
	{
		"inputs": [
			{
				"internalType": "string[]",
				"name": "_candidateName",
				"type": "string[]"
			}
		],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "vote",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "candidateCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "candidates",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "voteCount",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "getVoteCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "hasVoted",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];
const contract = new web3.eth.Contract(CONTRACT_ABI, CONTRACT_ADDR);

document.addEventListener("DOMContentLoaded", function(){
    if(window.ethereum){
        ethereum.request({method:"eth_requestAccounts"}).then((accounts) =>{
            account = accounts[0];
            console.log(account);

            contract.methods.candidateCount().call().then((count) => {
                for(var i = 1; i <= count; i++){
                    contract.methods.candidates(i).call().then((candidate) =>{
                        console.log(candidate);
                        document.getElementById(candidate.id).innerHTML = candidate.name;
                        document.getElementById("candidate"+candidate.id).innerHTML = candidate.voteCount;
                    });
                }
            });
        });
    } else {
        console.log("Please install MetaMask!");
    }
});


function vote(){
    var candidateId = document.getElementById("candidate").value;

    const transaction = {
        from:account,
        to:CONTRACT_ADDR,
        data:contract.methods.vote(candidateId).encodeABI(),
        gas:'300000'
    }

    web3.eth.sendTransaction(transaction).on("transactionHash", function(hash){
        console.log("Transaction Hash", hash)
    })
    .on("error", function(error){
        console.log(error)
    })
}
